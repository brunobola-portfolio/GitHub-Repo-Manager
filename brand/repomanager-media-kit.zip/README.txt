RepoManager — media kit
=======================

Everything in this archive is generated from one geometry definition in
scripts/gen-brand.mjs. If you need a variant that is not here, ask rather than
redrawing it — a hand-made copy will not match.

CONTENTS

  mark-display.svg / -inverse    The mark at 25 px and up, light / dark grounds
  mark-small.svg   / -inverse    The mark at 24 px and below (ring dropped)
  mark-mono.svg                  Single colour, inherits currentColor
  lockup-horizontal.svg / -inverse, lockup-stacked.svg
  tile-macos.svg                 824 art in a 1024 canvas, radius 185.4
  tile-windows.svg               256 square, radius 30
  tile-adaptive.svg              Mark at 58%, survives a circular mask
  repomanager.ico                16/24/32/48/64/256, correct cut per slot
  favicon-16/32.png, apple-touch-icon.png, icon-512.png, icon-1024-macos.png
  og-1200x630.png                Social card
  fonts/                         Archivo, IBM Plex Sans, JetBrains Mono
  BRAND.md                       The written spec — read this first

THE TWO RULES THAT MATTER MOST

  1. There are two optical cuts. Below 25 px use the small cut; it is not the
     display mark scaled down, it is redrawn. Shipping the display cut at
     16 px is the one mistake this system exists to prevent.

  2. The lime #7fc528 is fill only, never text, and never means "healthy".

COLOUR   lime #7fc528 · ink #0f172a · paper #f8fafc · ground #020617
TYPE     Archivo (display) · IBM Plex Sans (text) · JetBrains Mono (data)

FONTS    Bundled under the SIL Open Font Licence 1.1. See fonts/OFL.txt; the
         licence must travel with them.

TRADEMARK
         RepoManager manages GitHub repositories and is not affiliated with,
         endorsed by, or sponsored by GitHub, Inc. Do not use GitHub's marks,
         wordmark or palette alongside these assets.

         RepoManager and the RepoManager mark are assets of Bola Labs, Inc.
         Use them to refer to the product. Do not modify, recolour or
         reconstruct the mark, and do not use it to imply a partnership that
         does not exist.

Full spec: BRAND.md · https://github.com/brunobola-portfolio/GitHub-Repo-Manager
